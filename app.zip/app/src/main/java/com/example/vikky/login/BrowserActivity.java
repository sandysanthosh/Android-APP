package com.example.vikky.login;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;

public class BrowserActivity extends AppCompatActivity {



}
